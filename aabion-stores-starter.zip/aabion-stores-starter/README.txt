AABION STORES — SETUP GUIDE
===========================
Theme: black + lime green
Tagline: A Place of Trust
Currency: INR (₹)
Orders: private dashboard, manual payment arrangement

IMPORTANT
---------
This is a starter project, not yet a live store. You must connect a Supabase project and deploy it. Do not put a database password, service-role key, or other secret in app.js. The browser publishable/anon key is designed for frontend use only when RLS is correctly configured.

PART A — CREATE YOUR SUPABASE BACKEND
-------------------------------------
1. With a parent/guardian's help if required by account terms, create a Supabase account and a new project at https://supabase.com/.
2. Save the database password somewhere private. Never send it to ChatGPT or publish it.
3. Open the project's SQL Editor.
4. Open schema.sql from this folder, copy all its contents into the SQL Editor, and run it.
5. Open Authentication > Users and create your own admin user with an email and a strong, unique password. Do not reuse a password you shared in a chat.
6. In Authentication > Users, copy the UUID for that user.
7. In the SQL Editor, run this command, replacing the example UUID with your actual user UUID:

   insert into public.store_admins (user_id)
   values ('PASTE-YOUR-ADMIN-USER-UUID-HERE');

   Do not add anyone else's user ID. This is what grants admin permissions.
8. Open Project Settings / Connect (wording may vary) and copy the Project URL and publishable/anon key.
9. Edit app.js and replace these placeholders at the top:
   SUPABASE_URL = 'PASTE_YOUR_SUPABASE_PROJECT_URL_HERE'
   SUPABASE_PUBLISHABLE_KEY = 'PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE'
   Only use the publishable/anon key here. NEVER use a secret/service_role key in browser code.

PART B — TEST LOCALLY
---------------------
This uses JavaScript modules, so do not simply open index.html as a file.
1. Install Node.js from https://nodejs.org/ if needed.
2. Open a terminal in this folder.
3. Run:
   npx serve .
4. Open the local URL printed in the terminal.
5. Test: admin login, add a sample product, view it in the public shop, place a test order, and confirm only the admin can see the order.
6. Delete test orders/products before launch.

PART C — DEPLOY A FREE TEMPORARY WEBSITE
----------------------------------------
1. Create a GitHub repository for the project and upload index.html, styles.css, app.js, and schema.sql (do not upload passwords or secret keys).
2. Create/sign into Vercel at https://vercel.com/.
3. Choose Add New > Project, import the repository, and deploy. For this static starter, no build command is needed; if prompted, use the framework preset Other and the root directory.
4. Vercel will provide a temporary address ending in vercel.app. It may take a little time for the deployment to finish.
5. Open the public address on your phone and test all flows. Your temporary address is not automatically guaranteed to be indexed by Google.

PART D — GO LIVE CHECKLIST
--------------------------
[ ] Supabase SQL ran successfully.
[ ] Admin user created and its UUID added to public.store_admins.
[ ] Project URL and publishable key entered into app.js.
[ ] Admin can sign in and add/edit/delete products.
[ ] Public visitors can see only active products.
[ ] Test order appears in dashboard and is not visible to the public.
[ ] Product photos are owned/licensed for use and prices/stock are correct.
[ ] Supplier terms, shipping times, returns and customer support process are clear.
[ ] Test order and sample products removed.

FEATURES IN THIS STARTER
------------------------
- Responsive black/lime storefront with product search and category filtering.
- Product price, add-to-cart and quantity controls.
- Checkout with customer name, phone, address and 6-digit PIN code.
- Order saved in Supabase; manual payment arrangement only (no payment gateway).
- Admin login, product create/edit/delete, image upload and order status updates.
- Orders are restricted by database policies to approved admin accounts.

LIMITATIONS / NEXT STEPS
-----------------------
- It does not contact customers via WhatsApp yet.
- It does not automatically order items from Meesho, verify stock, or handle fulfilment/refunds.
- The public checkout is a basic direct database insert. For a commercial launch, add server-side validation and authoritative price calculation so clients cannot manipulate totals; add rate limiting/anti-spam and test security policies thoroughly.
- Customer addresses and phone numbers are personal data. Limit who can access them and establish a clear retention/deletion process.
- Product photos and prices in the database are your responsibility. Confirm your supplier permits your intended resale and fulfilment arrangement.
- No custom domain is needed initially; the temporary Vercel URL can be used for testing.
