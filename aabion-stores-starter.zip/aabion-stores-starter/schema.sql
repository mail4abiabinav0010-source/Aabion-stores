-- AABION STORES starter schema for Supabase.
-- Run in Supabase Dashboard > SQL Editor after creating a project.
-- Then create your admin user in Authentication > Users and follow README.txt to grant admin access.

create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 140),
  category text not null default 'Other' check (category in ('Fashion','Electronics','Home','Beauty','Accessories','Kitchen','Other')),
  description text not null default '' check (char_length(description) <= 1000),
  price numeric(12,2) not null check (price > 0),
  image_url text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_name text not null check (char_length(customer_name) between 1 and 100),
  phone text not null check (char_length(phone) between 5 and 20),
  address text not null check (char_length(address) between 5 and 500),
  pincode text not null check (pincode ~ '^[0-9]{6}$'),
  items jsonb not null check (jsonb_typeof(items) = 'array' and jsonb_array_length(items) > 0),
  total_amount numeric(12,2) not null check (total_amount > 0),
  payment_method text not null default 'manual' check (payment_method = 'manual'),
  status text not null default 'new' check (status in ('new','confirmed','ordered_from_supplier','shipped','delivered','cancelled')),
  created_at timestamptz not null default now()
);

-- Private allow-list for store admins. Only add an ID here from the SQL Editor.
create table if not exists public.store_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.store_admins enable row level security;

create or replace function public.is_store_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.store_admins a
    where a.user_id = (select auth.uid())
  );
$$;
revoke all on function public.is_store_admin() from public;
grant execute on function public.is_store_admin() to anon, authenticated;

-- Explicitly restrict table privileges, then allow only the intended operations.
revoke all on public.products from anon, authenticated;
revoke all on public.orders from anon, authenticated;
revoke all on public.store_admins from anon, authenticated;
grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
grant insert on public.orders to anon, authenticated;
grant select, update on public.orders to authenticated;

-- Anyone can view only active product listings; only an approved admin manages products.
drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products" on public.products for select to anon, authenticated using (is_active = true or public.is_store_admin());
drop policy if exists "Admins insert products" on public.products;
create policy "Admins insert products" on public.products for insert to authenticated with check (public.is_store_admin());
drop policy if exists "Admins update products" on public.products;
create policy "Admins update products" on public.products for update to authenticated using (public.is_store_admin()) with check (public.is_store_admin());
drop policy if exists "Admins delete products" on public.products;
create policy "Admins delete products" on public.products for delete to authenticated using (public.is_store_admin());

-- Visitors can submit an order, but cannot read or change any order through the API.
drop policy if exists "Visitors submit orders" on public.orders;
create policy "Visitors submit orders" on public.orders for insert to anon, authenticated with check (
  char_length(trim(customer_name)) > 0 and char_length(trim(phone)) >= 5
  and char_length(trim(address)) > 0 and pincode ~ '^[0-9]{6}$'
  and jsonb_typeof(items) = 'array' and jsonb_array_length(items) > 0
  and total_amount > 0 and payment_method = 'manual' and status = 'new'
);
drop policy if exists "Admins read orders" on public.orders;
create policy "Admins read orders" on public.orders for select to authenticated using (public.is_store_admin());
drop policy if exists "Admins update orders" on public.orders;
create policy "Admins update orders" on public.orders for update to authenticated using (public.is_store_admin()) with check (public.is_store_admin());

-- Do not expose the admin allow-list to browser clients.
-- Admin membership is only assigned manually through the Supabase SQL Editor.

-- Public product image bucket. Uploads/deletes are restricted to approved admins.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('aabion-products', 'aabion-products', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 5242880, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "Anyone can view AABION product images" on storage.objects;
create policy "Anyone can view AABION product images" on storage.objects for select to anon, authenticated using (bucket_id = 'aabion-products');
drop policy if exists "Admins upload AABION product images" on storage.objects;
create policy "Admins upload AABION product images" on storage.objects for insert to authenticated with check (bucket_id = 'aabion-products' and public.is_store_admin());
drop policy if exists "Admins update AABION product images" on storage.objects;
create policy "Admins update AABION product images" on storage.objects for update to authenticated using (bucket_id = 'aabion-products' and public.is_store_admin()) with check (bucket_id = 'aabion-products' and public.is_store_admin());
drop policy if exists "Admins delete AABION product images" on storage.objects;
create policy "Admins delete AABION product images" on storage.objects for delete to authenticated using (bucket_id = 'aabion-products' and public.is_store_admin());
